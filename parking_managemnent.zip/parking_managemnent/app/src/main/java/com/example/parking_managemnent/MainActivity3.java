package com.example.parking_managemnent;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

public class MainActivity3 extends AppCompatActivity {
    private Button registernbtn;
    private TextView backbtn2;
    private TextInputEditText full_name;
    private TextInputEditText username;
    private TextInputEditText password;
    SQLiteDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        registernbtn=findViewById(R.id.btnreg);
        backbtn2=findViewById(R.id.btnback);
        full_name=findViewById(R.id.full_name);
        username=findViewById(R.id.username);
        password=findViewById(R.id.user_password);
        db=openOrCreateDatabase("parking_management", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS admin_table(id_no INT,admin_full_name VARCHAR,admin_name VARCHAR,admin_password VARCHAR);");

        registernbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(full_name.getText().toString().trim().length()==0||
                        username.getText().toString().trim().length()==0||
                        password.getText().toString().trim().length()==0

                )
                {
                    Toast.makeText(getApplicationContext(),"\n" +"እባክዎ ሁሉንም እሴቶች ያስገቡ",Toast.LENGTH_LONG).show();

                    return;
                }
                db.execSQL("INSERT INTO admin_table VALUES('"+full_name.getText()+"','"+username.getText()+
                        "','"+password.getText()+"');");
                Toast.makeText(getApplicationContext(),"\n" +"መዝገብ በተሳካ ሁኔታ ታክሏል።",Toast.LENGTH_LONG).show();
                clearText();

            }
            public void clearText()
            {
                full_name.setText("");
                username.setText("");
                password.setText("");

            }


        });
        backbtn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"ምዝገባ",Toast.LENGTH_LONG).show();
                Intent i=new Intent(getApplicationContext(),MainActivity2.class);
                startActivity(i);
            }
        });
    }
}