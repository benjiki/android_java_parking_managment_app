package com.example.parking_managemnent;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.view.Menu;
import android.view.MenuItem;

import com.google.android.material.textfield.TextInputEditText;


public class MainActivity2 extends AppCompatActivity {
   private TextInputEditText car_plate;
   private TextInputEditText the_car_owner;
   private TextInputEditText phone_number;
   private TextInputEditText date;
   private TextInputEditText problems;
    private Button add;
    private Button delete;
    private Button modify;
    private Button view;
    private Button view_all;
    private Button logout;
    private Button developers;
    SQLiteDatabase db;
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id){
            case R.id.item1:
                Toast.makeText(getApplicationContext(),"ምዝገባ",Toast.LENGTH_LONG).show();
                Intent i=new Intent(getApplicationContext(),MainActivity3.class);
                startActivity(i);
                return true;
            case R.id.item2:
                Toast.makeText(getApplicationContext(),"አስተዳዳሪን ያስተዳድሩ",Toast.LENGTH_LONG).show();
                Intent i1=new Intent(getApplicationContext(),MainActivity4.class);
                startActivity(i1);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    //end
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        car_plate=findViewById(R.id.yemekinawe_Targa);
        the_car_owner=findViewById(R.id.yemekinawe_balebate);
        phone_number=findViewById(R.id.yemekinawe_balebate_seleke);
        date=findViewById(R.id.mekinawe_yegebabete_seate);
        add=findViewById(R.id.adder);
        delete=findViewById(R.id.delete);
        modify=findViewById(R.id.modify);
        view=findViewById(R.id.view);
        view_all=findViewById(R.id.viewall);
        developers=findViewById(R.id.the_developers);
        logout=findViewById(R.id.logout);
        problems=findViewById(R.id.mekinawe_yegodle_eka);

        db=openOrCreateDatabase("parking_management", Context.MODE_PRIVATE, null);
        db.execSQL("DROP TABLE IF EXISTS mekina_park");
        db.execSQL("CREATE TABLE IF NOT EXISTS mekina_park(car_plate VARCHAR,owner_name VARCHAR,phonenumber VARCHAR,DATE DATETIME,problems VARCAHR);");
       //start





        //end
    add.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if(car_plate.getText().toString().trim().length()==0||
                    the_car_owner.getText().toString().trim().length()==0||
                    phone_number.getText().toString().trim().length()==0||
                    date.getText().toString().trim().length()==0 ||
                    problems.getText().toString().trim().length()==0
            )
            {
                Toast.makeText(getApplicationContext(),"\n" +"እባክዎ ሁሉንም እሴቶች ያስገቡ",Toast.LENGTH_LONG).show();

                return;
            }
            db.execSQL("INSERT INTO mekina_park VALUES('"+car_plate.getText()+"','"+the_car_owner.getText()+
                    "','"+phone_number.getText()+"','"+date.getText()+"','"+problems.getText()+"');");
            Toast.makeText(getApplicationContext(),"\n" +"መዝገብ በተሳካ ሁኔታ ታክሏል።",Toast.LENGTH_LONG).show();
            clearText();

        }
        }
    );

    delete.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if(car_plate.getText().toString().trim().length()==0)
            {
                Toast.makeText(getApplicationContext(),"\n" +"እባክዎ ጥቅል ቁጥር ያስገቡ",Toast.LENGTH_LONG).show();

                return;
            }
            Cursor c=db.rawQuery("SELECT * FROM mekina_park WHERE car_plate='"+car_plate.getText()+"'", null);
            if(c.moveToFirst())
            {
                db.execSQL("DELETE FROM mekina_park WHERE car_plate='"+car_plate.getText()+"'");
                Toast.makeText(getApplicationContext(),"\n" +"መዝገብ ተሰርዟል።",Toast.LENGTH_LONG).show();

            }
            else
            {
                Toast.makeText(getApplicationContext(),"\n" +"ያለውን እውነተኛ ካርፕሌት አስገባ",Toast.LENGTH_LONG).show();


            }
            clearText();
        }

    });
    modify.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if(car_plate.getText().toString().trim().length()==0)
            {
                Toast.makeText(getApplicationContext(),"\n" +"እባክዎ ጥቅል ቁጥር ያስገቡ",Toast.LENGTH_LONG).show();

                return;
            }
            Cursor c=db.rawQuery("SELECT * FROM mekina_park WHERE car_plate='"+car_plate.getText()+"'", null);
            if(c.moveToFirst())
            {
                db.execSQL("UPDATE mekina_park SET owner_name='"+the_car_owner.getText()+"',phonenumber='"+phone_number.getText()+
                        "', DATE='"+date.getText()+"' WHERE car_plate='"+car_plate.getText()+"'");
                Toast.makeText(getApplicationContext(),"\n" +"መዝገብ ተስተካክሏል።",Toast.LENGTH_LONG).show();


            }
            else
            {
                Toast.makeText(getApplicationContext(),"\n" +"ያለውን እውነተኛ ካርፕሌት አስገባ",Toast.LENGTH_LONG).show();

            }
            clearText();

        }
    });
   view.setOnClickListener(new View.OnClickListener() {
       @Override
       public void onClick(View v) {
           if(car_plate.getText().toString().trim().length()==0)
           {
               Toast.makeText(getApplicationContext(),"\n" +"እባክዎ ጥቅል ቁጥር ያስገቡ",Toast.LENGTH_LONG).show();
               return;
           }
           Cursor c=db.rawQuery("SELECT * FROM mekina_park WHERE car_plate='"+car_plate.getText()+"'", null);
           if(c.moveToFirst())
           {

               the_car_owner.setText(c.getString(1));
               phone_number.setText(c.getString(2));
               date.setText(c.getString(3));
           }
           else
           {
               Toast.makeText(getApplicationContext(),"\n" +"ያለውን እውነተኛ ካርፕሌት አስገባ",Toast.LENGTH_LONG).show();

               clearText();
           }
       }

   });
    view_all.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Cursor c=db.rawQuery("SELECT * FROM mekina_park", null);
            if(c.getCount()==0)
            {
                showMessage("Error", "No records found");
                return;
            }
            StringBuffer buffer=new StringBuffer();
            while(c.moveToNext())
            {
                buffer.append("car_plate: "+c.getString(0)+"\n");
                buffer.append("owner_name: "+c.getString(1)+"\n");
                buffer.append("phonenumber: "+c.getString(2)+"\n");
                buffer.append("DATE: "+c.getString(3)+"\n");
                buffer.append("problems: "+c.getString(4)+"\n\n");

            }
            showMessage("parked car details", buffer.toString());
        }

    });
    developers.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            showMessage("የመኪና ማቆሚያ አስተዳደር ስርዓት", "\n" + "ፈጣሪዎቹ  "+
                                                                "\n" +"1.ቢኒያም_ዮሴፍ "+
                                                                "\n" +"2.ናሆም_ደመላሽ "+
                                                                "\n" +"3.ማሃምዲን_ሙሰማ "+
                                                                "\n" +"4.አቤል_ኡመር "+
                                                                "\n" +"5.ርብቃ_አሰፋ "+
                                                                "\n" +"6.ሱራፍል_ተወልደብርሃን"+
                                                                "\n" +"7.ልኡል_ተፈሪ "
            );

        }
    });
    logout.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Toast.makeText(getApplicationContext(),"logged out  successfully",Toast.LENGTH_LONG).show();
            Intent i=new Intent(getApplicationContext(),MainActivity.class);
            startActivity(i);
        }
    });
    }

    public void clearText()
    {
        car_plate.setText("");
        the_car_owner.setText("");
        phone_number.setText("");
        date.setText("");
        problems.setText("");
    }
    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}