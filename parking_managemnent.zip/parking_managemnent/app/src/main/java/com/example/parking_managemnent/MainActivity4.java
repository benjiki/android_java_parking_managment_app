package com.example.parking_managemnent;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity4 extends AppCompatActivity {
  private EditText full_name,username,user_password;
  private Button btndelete,btnview,btnviewall,btnmodify;
    SQLiteDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
        full_name=findViewById(R.id.full_name);
        username=findViewById(R.id.username);
        user_password=findViewById(R.id.user_password);
        btndelete=findViewById(R.id.btndelete);
        btnview=findViewById(R.id.btnview);
        btnviewall=findViewById(R.id.btnviewall);
        btnmodify=findViewById(R.id.btnmodify);
        db=openOrCreateDatabase("parking_management", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS admin_table(id_no INT,admin_full_name VARCHAR,admin_name VARCHAR,admin_password VARCHAR);");

        btndelete.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
              if(username.getText().toString().trim().length()==0)
              {
                  Toast.makeText(getApplicationContext(),"\n" +"እባክዎ ጥቅል ቁጥር ያስገቡ",Toast.LENGTH_LONG).show();

                  return;
              }
              Cursor c=db.rawQuery("SELECT * FROM admin_table WHERE admin_name='"+username.getText()+"'", null);
              if(c.moveToFirst())
              {
                  db.execSQL("DELETE FROM admin_table WHERE admin_name='"+username.getText()+"'");
                  Toast.makeText(getApplicationContext(),"\n" +"መዝገብ ተሰርዟል።",Toast.LENGTH_LONG).show();

              }
              else
              {
                  Toast.makeText(getApplicationContext(),"\n" +"ያለውን እውነተኛ ካርፕሌት አስገባ",Toast.LENGTH_LONG).show();


              }
           clearText();
          }
      });
     btnview.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View v) {
             if(username.getText().toString().trim().length()==0)
             {
                 Toast.makeText(getApplicationContext(),"\n" +"እባክዎ ጥቅል ቁጥር ያስገቡ",Toast.LENGTH_LONG).show();
                 return;
             }
             Cursor c=db.rawQuery("SELECT * FROM admin_table WHERE admin_name='"+username.getText()+"'", null);
             if(c.moveToFirst())
             {

                 full_name.setText(c.getString(1));
                 user_password.setText(c.getString(2));

             }
             else
             {
                 Toast.makeText(getApplicationContext(),"\n" +"ያለውን እውነተኛ ካርፕሌት አስገባ",Toast.LENGTH_LONG).show();

                 clearText();
             }
         }

     });
    btnviewall.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {

                Cursor c=db.rawQuery("SELECT * FROM admin_table", null);
                if(c.getCount()==0)
                {
                    showMessage("Error", "No records found");
                    return;
                }
                StringBuffer buffer=new StringBuffer();
                while(c.moveToNext())
                {
                    buffer.append("full_name: "+c.getString(0)+"\n");
                    buffer.append("admin_name: "+c.getString(1)+"\n");
                    buffer.append("admin_password: "+c.getString(2)+"\n\n");

                }
                showMessage("admin users", buffer.toString());

        }
    });
     btnmodify.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View v) {

             if(username.getText().toString().trim().length()==0)
             {
                 Toast.makeText(getApplicationContext(),"\n" +"እባክዎ ጥቅል ቁጥር ያስገቡ",Toast.LENGTH_LONG).show();

                 return;
             }
             Cursor c=db.rawQuery("SELECT * FROM admin_table WHERE admin_name='"+username.getText()+"'", null);
             if(c.moveToFirst())
             {
                 db.execSQL("UPDATE admin_table SET  admin_password='"+user_password.getText()+
                         "' WHERE admin_name='"+username.getText()+"'");
                 Toast.makeText(getApplicationContext(),"\n" +"መዝገብ ተስተካክሏል።",Toast.LENGTH_LONG).show();


             }
             else
             {
                 Toast.makeText(getApplicationContext(),"\n" +"ያለውን እውነተኛ ካርፕሌት አስገባ",Toast.LENGTH_LONG).show();

             }
             clearText();


         }
     });
    }


    public void clearText()
    {
        full_name.setText("");
        username.setText("");
        user_password.setText("");

    }
    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}