package com.example.parking_managemnent;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity6 extends AppCompatActivity {
    private static final int pic_id = 123;
    private static final int pic_id1 = 12;
    private static final int pic_id2 = 1;
    SQLiteDatabase db;


    public String b;
    FrameLayout frameLayout;
    Button camera_open_id;
    ImageView click_image_id,image_btn1,image_btn2;
    EditText car_plate;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);
        camera_open_id = findViewById(R.id.camera_button);
        click_image_id = findViewById(R.id.click_image);
        image_btn1     =     findViewById(R.id.click1_image);
        image_btn2 = findViewById(R.id.click2_image);
        car_plate = findViewById(R.id.carpate);
        db=openOrCreateDatabase("parking_management", Context.MODE_PRIVATE, null);
        db.execSQL("DROP TABLE IF EXISTS mekina_park_problems");
        db.execSQL("CREATE TABLE IF NOT EXISTS mekina_park_problems(car_targa varchar,image1 BLOB,image2 BLOB,image3 BLOB);");


        image_btn1.setOnClickListener(v -> {
            // Create the camera_intent ACTION_IMAGE_CAPTURE it will open the camera for capture the image
            Intent camera_intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            // Start the activity with camera_intent, and request pic id1
            startActivityForResult(camera_intent, pic_id1);
        });
        image_btn2.setOnClickListener(v -> {
            // Create the camera_intent ACTION_IMAGE_CAPTURE it will open the camera for capture the image
            Intent camera_intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            // Start the activity with camera_intent, and request pic id1
            startActivityForResult(camera_intent, pic_id2);
        });
        click_image_id.setOnClickListener(v -> {
            // Create the camera_intent ACTION_IMAGE_CAPTURE it will open the camera for capture the image
            Intent camera_intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            // Start the activity with camera_intent, and request pic id1
            startActivityForResult(camera_intent, pic_id);
        });

        camera_open_id.setOnClickListener(v -> {

         //start

            if (image_btn1.getDrawable() == null){
                //Image doesn´t exist.
                Toast.makeText(getApplicationContext(),"\n" +"እባክዎ ሁሉንም እሴቶች ያስገቡ",Toast.LENGTH_LONG).show();

            }else {
                //Image Exists!.


                db.execSQL("INSERT INTO mekina_park_problems VALUES('"+car_plate.getText()+"','"+click_image_id.getDrawable()+"'+'"+image_btn1.getDrawable()+"'+'"+image_btn2.getDrawable()+"'");
                Toast.makeText(getApplicationContext(), "\n" + "መዝገብ በተሳካ ሁኔታ ታክሏል።", Toast.LENGTH_LONG).show();
            }



            //end


        });


    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // Match the request 'pic id with requestCode
        if (requestCode == pic_id) {
            // BitMap is data structure of image file which store the image in memory
            Bitmap photo = (Bitmap) data.getExtras().get("data");
            // Set the image in imageview for display
            click_image_id.setImageBitmap(photo);

        }

        if (requestCode == pic_id1) {
            // BitMap is data structure of image file which store the image in memory
            Bitmap photo = (Bitmap) data.getExtras().get("data");
            // Set the image in imageview for display
            image_btn1.setImageBitmap(photo);

        }
        if (requestCode == pic_id2) {
            // BitMap is data structure of image file which store the image in memory
            Bitmap photo = (Bitmap) data.getExtras().get("data");
            // Set the image in imageview for display
            image_btn2.setImageBitmap(photo);
        }
        if (requestCode == pic_id) {
            // BitMap is data structure of image file which store the image in memory
            Bitmap photo = (Bitmap) data.getExtras().get("data");
            // Set the image in imageview for display
            click_image_id.setImageBitmap(photo);
        }
    }


}



