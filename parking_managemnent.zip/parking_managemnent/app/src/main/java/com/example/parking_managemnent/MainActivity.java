package com.example.parking_managemnent;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.view.Menu;
import android.view.MenuItem;

import com.google.android.material.textfield.TextInputEditText;


public class MainActivity extends AppCompatActivity {
private Button loginbtn,loginbtn2;
private TextInputEditText username;
private TextInputEditText password;
    SQLiteDatabase db;


    //start
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id){
            case R.id.item1:
                Toast.makeText(getApplicationContext(),"ምዝገባ",Toast.LENGTH_LONG).show();
                Intent i=new Intent(getApplicationContext(),MainActivity3.class);
                startActivity(i);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }
//end
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        username = findViewById(R.id.UserEdT);
        password = findViewById(R.id.PassEdT);
        loginbtn =findViewById(R.id.btnlogin);
        loginbtn2=findViewById(R.id.btnimage);
        db=openOrCreateDatabase("parking_management", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS admin_table(id_no INT,admin_name VARCHAR,admin_password VARCHAR);");

        loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //start
                Cursor c=db.rawQuery("SELECT * FROM admin_table WHERE admin_name='"+username.getText()+"' and admin_password='"+username.getText()+"'", null);

                if(c.getCount()==0)
                {
                    Toast.makeText(getApplicationContext(),"wrong password please try again",Toast.LENGTH_LONG).show();
                    clearText();
                    return;
                }
                else
                {

                    Toast.makeText(getApplicationContext(),"login  successfully",Toast.LENGTH_LONG).show();
                    Intent i=new Intent(getApplicationContext(),MainActivity2.class);
                    startActivity(i);
                }
            }


                //end





        });
       loginbtn2.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Intent i=new Intent(getApplicationContext(),MainActivity6.class);
               startActivity(i);
           }
       });

    }
    public void clearText()
    {
        username.setText("");
        password.setText("");

    }
}